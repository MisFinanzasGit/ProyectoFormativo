<?php


require_once "model/Cuenta.php";
require_once "model/Usuario.php";
require_once "model/TipoCuenta.php";

class CuentaController
{
    public $model;

    public function __construct()
    {
        $this->model = new Cuenta();
    }

 

    public function index()
    {
        require_once "view/header.php";
        require_once "view/cuenta/index.php";
        //require_once "view/footer.php";
    }

    public function crear()
    {
        require_once "view/header.php";
        $c = new Cuenta();
        $tc = new TipoCuenta();
        require_once "view/cuenta/index.php";

    }

    public function guardar()
    {
     $c = new Cuenta();
     $tc = new TipoCuenta();
     $mu = new Usuario();


     $c->setCuenta_nom($_POST["Nombre"]);
     $c->setCuenta_tipo(intval($_POST["Tipo"]));
     $c->setCuenta_usuario(1);
     $c->setCuenta_monto(intval($_POST["Monto"]));
     $c->setCuenta_saldo(intval($_POST["Monto"]));

     //echo var_dump($c);
     $this->model->insertarCuenta($c);

        header("location:?c=cuenta&a=crear");
    }


    public function eliminar()
    {
        if(isset($_GET["Id"]))
        {
            $this->model->Eliminar($_GET["id"]);
            header("location:?c=cuenta");
        }
    }



}

