<?php

require_once "model/Presupuesto.php";
require_once "model/Cuenta.php";
require_once "model/Usuario.php";
require_once "model/Gasto.php";


class GastoController

{
    public $model;

    public function __construct()
    {
        $this->model = new Gasto();
    }

    public function crear()
    {
        require_once "view/header.php";
        $gasto = new Gasto();
        require_once "view/presupuesto/index.php";

    }

    public function guardar()
    {
        $gasto = new Gasto();

        $gasto->setGasto_nombre($_POST["Nombre"]);
        $gasto->setGasto_presupuesto($_POST["PTO"]);
        $gasto->setGasto_categoria($_POST["CTA"]);
        $gasto->setGasto_descripcion($_POST["Descripcion"]);

        //echo var_dump($gasto);
        $this->model->insertarGasto($gasto);

        header("location:?c=presupuesto&a=crear");
    }

}