<?php

require_once "model/Categoria.php";
require_once "model/Usuario.php";

class CategoriaController
{
    public $model;

    public function __construct()
    {
        $this->model = new Categoria();
    }



    public function index()
    {
        require_once "view/header.php";
        require_once "view/cuenta/index.php";
        //require_once "view/footer.php";
    }

    public function crear()
    {
        require_once "view/header.php";
        $c = new Cuenta();
        $tc = new TipoCuenta();
        require_once "view/presupuesto/index.php";

    }

    public function guardar()
    {
        $cat = new Categoria();


        $cat->set_CategoriaTipo($_POST["Nombre"]);



        //echo var_dump($cat);
        $this->model->insertarCategoria($cat);

       header("location:?c=presupuesto&a=crear");
    }


    public function eliminar()
    {
        if(isset($_GET["Id"]))
        {
            $this->model->Eliminar($_GET["id"]);
            header("location:?c=cuenta");
        }
    }



}
