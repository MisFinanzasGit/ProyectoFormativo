<?php


require_once "model/Usuario.php";

class UsuarioController
{
    public $model;

    public function __construct()
    {
        $this->model = new Usuario();
    }

    public function home()

    {
        require_once "view/footer.php";
        require_once "view/usuario/home.php";
    }


    public function login()
    {
   
        require_once "view/usuario/login.php";

    }

    public function iniciar()
    {
        $user = $this->model->validar($_POST['user'], $_POST['pass']);

        if ($user) {
            header("location:?c=home&a=index");
        } else {
            header("location:index.php?error");
        }

    }

    public function cerrar()
    {
        session_destroy();
        header("location:index.php");
    }

    public function index()
    {
        require_once "view/header.php";
        require_once "view/usuario/index.php";

    }

    public function crear()
    {
        $u = new Usuario();
        $titulo="Registro Usuario";
    
        require_once "view/usuario/registro.php";

    }

    public function guardar()
    {
     $u = new Usuario();


     $u->setUsu_Nom($_POST["Nombre"]);
     $u->setUsu_Ape($_POST["Apellido"]);
     $u->set_UsuCorr($_POST["Correo"]);
     $u->set_UsuPass(md5(sha1($_POST["Pass"])));
     $u->set_UsuSexo($_POST["Sexo"]);
     $u->set_UsuFNA($_POST["FNA"]);

     $this->model->insertarUsuario($u);

        header("location:?c=usuario&a=home");

    }

    public function eliminar()
    {
        if(isset($_GET["Id"]))
        {
            $this->model->Elimiar($_GET["id"]);
            header("location:?c=usuario");
        }
    }



}