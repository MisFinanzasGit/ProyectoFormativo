<?php

require_once "model/Metafinanciera.php";
require_once "model/TipoMeta.php";


class MetaController
{
public $model;

public function __construct()
{
$this->model = new Metafinanciera();
}



public function index()
{
require_once "view/header.php";
require_once "view/meta/index.php";
//require_once "view/footer.php";
}

public function crear()
{
    require_once "view/header.php";
$mf = new Metafinanciera();
$tmf = new TipoMeta();
require_once "view/home/index.php";

}

public function guardar()
{
$mf = new Metafinanciera();


$mf->setMeta_usuario(1);
$mf->setMeta_nom($_POST["Nombre"]);
$mf->setMeta_costo(intval($_POST["Costo"]));
$mf->setMeta_tipo($_POST["Tipo"]);


//echo var_dump($mf);
$this->model->insertarMeta($mf);

header("location:?c=meta&a=crear#metas");
}


public function eliminar()
{
if(isset($_GET["Id"]))
{
$this->model->Eliminar($_GET["id"]);
header("location:?c=cuenta");
}
}



}