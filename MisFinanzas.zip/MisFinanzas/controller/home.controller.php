<?php

require_once 'model/Metafinanciera.php';
require_once 'model/TipoMeta.php';
class HomeController
{
    public function index()
    {
        require_once "view/header.php";
        $mf = new Metafinanciera();
        $tmf = new TipoMeta();
        require_once "view/home/index.php";

    }
}
