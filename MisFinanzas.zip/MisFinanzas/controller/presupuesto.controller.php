<?php

require_once "model/Presupuesto.php";
require_once "model/Cuenta.php";
require_once "model/Usuario.php";
require_once "model/Gasto.php";
require_once "model/Categoria.php";

class PresupuestoController
{
    public $model;

    public function __construct()
    {
        $this->model = new Presupuesto();
    }

    public function index()
    {
        require_once "view/header.php";
        require_once "view/cuenta/index.php";
        //require_once "view/footer.php";
    }

    public function crear()
    {
        require_once "view/header.php";
        $cat = new Categoria();
        $pto = new Presupuesto();
        $c = new Cuenta();
        $gasto = new Gasto();
        require_once "view/presupuesto/index.php";

    }

    public function guardar()
    {
        $pto = new Presupuesto();
        $c = new Cuenta();


        $pto->setPresu_Nombre($_POST["Nombre"]);
        $pto->setPresu_Cuenta(intval($_POST["Cuenta"]));
        $pto->setPresu_Monto(intval($_POST["Monto"]));
        $pto->setPresu_Saldo(intval($_POST["Monto"]));


        //echo var_dump($pto);
        $this->model->insertarPresupuesto($pto);

       header("location:?c=presupuesto&a=crear");
    }
}