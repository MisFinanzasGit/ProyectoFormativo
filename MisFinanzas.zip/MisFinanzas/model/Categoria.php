<?php

class Categoria
{
    private $idCategoria;
    private $categoria_tipo;
    private $categoria_icon;


    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }


    public function __construct1(int $idCategoria,string $categoria_tipo,string $categoria_icon)
    {
        $this->idCategoria=$idCategoria;
        $this->categoria_tipo=$categoria_tipo;
        $this->categoria_icon=$categoria_icon;
    }

    public function set_CategoriaId(int $id)
    {
        $this->idCategoria=$id;
    }

    public function get_CategoriaId():?int
    {
        return $this->idCategoria;
    }

    public function set_CategoriaTipo(string $tipo)
    {
        $this->categoria_tipo=$tipo;
    }

    public function get_CategoriaTipo():?string
    {
        return $this->categoria_tipo;
    }

    public function set_Categoriaicon(string $icon)
    {
        $this->categoria_icon=$icon;
    }

    public function get_Categoriaicon():?string
    {
        return $this->categoria_icon;
    }

    public function Listar()
    {
        try{
            $consulta="call listarCategoria()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }



    public function insertarCategoria(categoria $cat)
    {
        try{

            $sentencia = "call insertCategoria(?);";

            $this->pdo->prepare($sentencia)
                ->execute(
                    array(
                        $cat->get_CategoriaTipo(),

                    )
                );
        }
        catch (Exception $e)
        {
            die($e->getMessage());

        }
    }


}