<?php

class TipoMovimiento
{

}