<?php

class Gasto
{
    private $idGasto;
    private $gasto_nombre;
    private $gasto_descripcion;
    private $gasto_categoria;
    private $gasto_presupuesto;
    private $fecha_inicial;
    private $fecha_final;


    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }


    public function __construct1(int $idGasto, string $gasto_nombre, string $gasto_descripcion, int $gasto_prespuesto,int $gasto_categoria,
                                 string $fecha_inicial, string $fecha_final)
    {
        $this->idGasto=$idGasto;
        $this->gasto_nombre=$gasto_nombre;
        $this->gasto_presupuesto=$gasto_prespuesto;
        $this->gasto_categoria=$gasto_categoria;
        $this->gasto_descripcion=$gasto_descripcion;
        $this->fecha_inicial=$fecha_inicial;
        $this->fecha_final=$fecha_final;
    }



    public function setGasto_id(int $id)
    {
        $this->idGasto=$id;
    }

    public function getGasto_id():?int
    {
        return $this->idGasto;
    }

    public function setGasto_nombre(string $nombre)
    {
        $this->gasto_nombre=$nombre;
    }

    public function getGasto_nombre():?string
    {
        return $this->gasto_nombre;
    }

    public function setGasto_presupuesto(int $presupuesto)
    {
        $this->gasto_presupuesto=$presupuesto;
    }

    public function getGasto_presupuesto():?int
    {
        return $this->gasto_presupuesto;
    }

    public function setGasto_descripcion(string $descripcion)
    {
        $this->gasto_descripcion=$descripcion;
    }

    public function getGasto_descripcion():?string
    {
        return $this->gasto_descripcion;
    }

    public function setGasto_categoria(int $categoria)
    {
        $this->gasto_categoria=$categoria;
    }

    public function getGasto_categoria():?int
    {
        return $this->gasto_categoria;
    }

    public function setGasto_fechainicial(string $fechainicial)
    {
        $this->gasto_fechainicial=$fechainicial;
    }

    public function getGasto_fechainicial():?string
    {
        return $this->gasto_fechainicial;
    }

    public function setGasto_fechafinal(string $fechafinal)
    {
        $this->gasto_fechafinal=$fechafinal;
    }

    public function getGasto_fechafinal():?string
    {
        return $this->gasto_fechafinal;
    }



    public function Listar()
    {
        try{
            $consulta="call listarGasto()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }




    public function insertarGasto(gasto $gasto)
    {
        try{

            $sentencia = "call insertGasto(?,?,?,?);";

            $this->pdo->prepare($sentencia)
                ->execute(
                    array(
                        $gasto->getGasto_nombre(),
                        $gasto->getGasto_presupuesto(),
                        $gasto->getGasto_categoria(),
                        $gasto->getGasto_descripcion()

                    )
                );
        }
        catch (Exception $e)
        {
            die($e->getMessage());

        }
    }











}