<?php

class TipoCuenta
{
    private $idcuenta_tipo;
    private $tipo_cuenta;



    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }

    public function __construct1(int $idcuenta_tipo,string $tipo_cuenta)
    {

        $this->idcuenta_tipo=$idcuenta_tipo;
        $this->tipo_cuenta=$tipo_cuenta;

    }

    public function set_TipoCuentaId(int $id)
    {
        $this->idcuenta_tipo=$id;
    }

    public function get_TipoCuentaId():?int
    {
        return $this->idcuenta_tipo;
    }

    public function set_TipoCuenta(string $tipoc)
    {
        $this->tipo_cuenta=$tipoc;
    }


    public function get_TipoCuenta_id():?string
    {
        return $this->tipo_cuenta;
    }




    public function Listar()
    {
        try{
            $consulta="call listartcuenta()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }

}

