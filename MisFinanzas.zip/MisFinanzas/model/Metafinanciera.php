<?php

class Metafinanciera
{
    private $Idmetafinanciera;
    private $meta_usuario;
    private $meta_nom;
    private $meta_costo;
    private $meta_tipo;
    private $fecha_inicial;
    private $fecha_final;

    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }

    public function __construct1(int $Idmetafinanciera,int $meta_usuario,string $meta_nom,float $meta_costo,int $meta_tipo,string $fecha_inicial,string $fecha_final)
    {
        $this->Idmetafinanciera=$Idmetafinanciera;
        $this->meta_usuario=$meta_usuario;
        $this->meta_nom=$meta_nom;
        $this->meta_costo=$meta_costo;
        $this->meta_tipo=$meta_tipo;
        $this->fecha_inicial=$fecha_inicial;
        $this->fecha_final=$fecha_final;
    ;
    }


    public function setMeta_id(int $id)
    {
        $this->Idmetafinanciera=$id;
    }

    public function getMeta_id():?int
    {
        return $this->Idmetafinanciera;
    }

    public function setMeta_usuario(int $usuario)
    {
        $this->meta_usuario=$usuario;
    }

    public function getMeta_usuario():?int
    {
        return $this->meta_usuario;
    }

    public function setMeta_nom(string $nom)
    {
        $this->meta_nom=$nom;
    }

    public function getMeta_nom():?string
    {
        return $this->meta_nom;
    }

    public function setMeta_costo(float $costo)
    {
        $this->meta_costo=$costo;
    }

    public function getMeta_costo():?float
    {
        return $this->meta_costo;
    }

    public function setMeta_tipo(int $tipo)
    {
        $this->meta_tipo=$tipo;
    }

    public function getMeta_tipo():?int
    {
        return $this->meta_tipo;
    }

    public function setMeta_fechainicial(string $fechainicial)
    {
        $this->meta_fechainicial=$fechainicial;
    }

    public function getMeta_fechainicial():?string
    {
        return $this->meta_fechainicial;
    }

    public function setMeta_fechafinal(string $fechafinal)
    {
        $this->meta_fechafinal=$fechafinal;
    }

    public function getMeta_fechafinal():?string
    {
        return $this->meta_fechafinal;
    }

    public function Listar()
    {
        try{
            $consulta="call listarMetaF()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    public function nMetas()
    {

        try{
            $consulta="call nmetas()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }


    }


    public function costoMetas()
    {

        try{
            $consulta="call costometa()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }


    }




    public function insertarMeta(Metafinanciera $meta)
    {
        try{

            $sentencia = "call insertMeta(?,?,?,?);";

            $this->pdo->prepare($sentencia)
                ->execute(
                    array(
                        $meta->getMeta_usuario(),
                        $meta->getMeta_nom(),
                        $meta->getMeta_costo(),
                        $meta->getMeta_tipo()

                    )
                );
        }
        catch (Exception $e)
        {
            die($e->getMessage());

        }
    }





}
