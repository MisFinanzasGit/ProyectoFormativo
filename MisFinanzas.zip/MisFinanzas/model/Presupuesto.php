<?php

class Presupuesto
{
    private $idPresupuesto;
    private $presu_Nombre;
    private $presu_Saldo;
    private $presu_monto;
    private $presu_Cuenta;

    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }

    public function __construct1(int $idPresupiuesto,string $presu_Nombre,float $presu_Saldo,float $presu_monto,$presu_Cuenta)
    {
        $this->idPresupuesto=$idPresupiuesto;
        $this->presu_Nombre=$presu_Nombre;
        $this->presu_Saldo=$presu_Saldo;
        $this->presu_monto=$presu_monto;
        $this->presu_Cuenta=$presu_Cuenta;

    }

    public function setPresu_id(int $id)
    {
        $this->idPresupuesto=$id;
    }

    public function getPresu_id():?int
    {
        return $this->idPresupuesto;
    }

    public function setPresu_Nombre(string $nom)
    {
        $this->presu_Nombre=$nom;
    }

    public function getPresu_Nombre():?string
    {
        return $this->presu_Nombre;
    }

    public function setPresu_Saldo(float $saldo)
    {
        $this->presu_Saldo=$saldo;
    }

    public function getPresu_Saldo():?float
    {
        return $this->presu_Saldo;
    }

    public function setPresu_Monto(float $monto)
    {
        $this->presu_monto=$monto;
    }

    public function getPresu_Monto():?float
    {
        return $this->presu_monto;
    }

    public function setPresu_Cuenta(int $cuenta)
    {
        $this->presu_Cuenta=$cuenta;
    }

    public function getPresu_Cuenta():?int
    {
        return $this->presu_Cuenta;
    }


    public function Listar()
    {
        try{
            $consulta="call listarPresupuesto()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    public function insertarPresupuesto(presupuesto $pto)
    {
        try{

            $sentencia = "call insertPresupuesto(?,?,?,?);";

            $this->pdo->prepare($sentencia)
                ->execute(
                    array(
                        $pto->getPresu_Nombre(),
                        $pto->getPresu_Cuenta(),
                        $pto->getPresu_Monto(),
                        $pto->getPresu_Saldo()
                    )
                );
        }
        catch (Exception $e)
        {
            die($e->getMessage());

        }
    }






}
