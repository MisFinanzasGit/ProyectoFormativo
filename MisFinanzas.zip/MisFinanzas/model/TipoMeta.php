<?php

class TipoMeta
{
    private $idtipo_meta;
    private $tipo_meta;

    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }

    public function __construct1(int $idtipo_meta,string $tipo_meta)
    {

        $this->idtipo_metao=$idtipo_meta;
        $this->tipo_meta=$tipo_meta;

    }

    public function set_TipometaId(int $id)
    {
        $this->idtipo_meta=$id;
    }

    public function get_TipometaId():?int
    {
        return $this->idtipo_meta;
    }

    public function set_Tipometa(int $tipo)
    {
        $this->tipo_meta=$tipo;
    }

    public function get_Tipometa():?int
    {
        return $this->tipo_meta;
    }

    public function Listar()
    {
        try{
            $consulta="call listarttmeta()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }

}