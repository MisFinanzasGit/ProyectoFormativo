<?php

class Cuenta
{
    private $idCuenta;
    private $cuenta_nom;
    private $cuenta_tipo;
    private $cuenta_usuario;
    private $cuenta_monto;
    private $cuenta_saldo;
 

    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }

    public function __construct1(int $idCuenta,string $cuenta_nom,int $cuenta_tipo,int $cuenta_usuario,float $cuenta_monto,float $cuenta_saldo)
    {

        $this->idCuenta=$idCuenta;
        $this->cuenta_nom=$cuenta_nom;
        $this->cuenta_tipo=$cuenta_tipo;
        $this->cuenta_usuario=$cuenta_usuario;
        $this->cuenta_monto=$cuenta_monto;
        $this->cuenta_saldo=$cuenta_saldo;

     
    }

    public function setCuenta_id(int $id)
    {
        $this->idCuenta=$id;
    }

    public function getCuenta_id():?int
    {
        return $this->idCuenta;
    }

      public function setCuenta_nom(string $nom)
    {
        $this->cuenta_nom=$nom;
    }

    public function getCuenta_nom():?string
    {
        return $this->cuenta_nom;
    }

     public function setCuenta_tipo(int $tipo)
    {
        $this->cuenta_tipo=$tipo;
    }

    public function getCuenta_tipo():?int
    {
        return $this->cuenta_tipo;
    }

      public function setCuenta_usuario(int $usuario)
    {
        $this->cuenta_usuario=$usuario;
    }

    public function getCuenta_usuario():?int
    {
        return $this->cuenta_usuario;
    }

       public function setCuenta_monto(float $monto)
    {
        $this->cuenta_monto=$monto;
    }

    public function getCuenta_monto():?float
    {
        return $this->cuenta_monto;
    }


       public function setCuenta_saldo(float $saldo)
    {
        $this->cuenta_saldo=$saldo;
    }

    public function getCuenta_saldo():?float
    {
        return $this->cuenta_saldo;
    }


    public function Listar()
    {
        try{
            $consulta="call listarCuenta()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }

    public function ListarTodo()
    {
        try{
            $consulta="call listarCuentatod()";
            $sentencia=$this->pdo->prepare($consulta);
            $sentencia->execute();

            return $sentencia->fetchAll(PDO::FETCH_OBJ);

        }catch(Exception $e){
            die($e->getMessage());
        }

    }


    public function insertarCuenta(cuenta $c)
    {
        try{
            
            $sentencia = "call insertCuenta(?,?,?,?,?);";

            $this->pdo->prepare($sentencia)
                ->execute(
                    array(
                        $c->getCuenta_nom(),
                        $c->getCuenta_tipo(),
                        $c->getCuenta_usuario(),
                        $c->getCuenta_monto(), 
                        $c->getCuenta_saldo()            
                    )
                );
        }
        catch (Exception $e)
        {
            die($e->getMessage());

        }
    }




}

