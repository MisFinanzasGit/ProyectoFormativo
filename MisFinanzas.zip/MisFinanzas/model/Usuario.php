<?php

class Usuario
{
    private $idUsuario;
    private $usu_Nombre;
    private $usu_Apellido;
    private $usu_Correo;
    private $usu_Password;
    private $usu_Sexo;
    private $usu_FNA;

    public function __construct()
    {
        $this->pdo = Database::Conectar();
    }

    public function __construct1(int $idUsuario, string $usu_Nombre, string $usu_Apellido,
                                 string  $usu_Correo, string $usu_Password, Char $usu_Sexo, string $usu_FNA)
    {
        $this->idUsuario=$idUsuario;
        $this->usu_Nombre=$usu_Nombre;
        $this->usu_Apellido=$usu_Apellido;
        $this->usu_Correo=$usu_Correo;
        $this->usu_Password=$usu_Password;
        $this->usu_Sexo=$usu_Sexo;
        $this->usu_FNA=$usu_FNA;
    }

    public function setUsu_Id(int $id)
    {
        $this->idUsuario=$id;
    }

    public function getUsu_id():?int
    {
        return $this->idUsuario;
    }

    public function setUsu_Nom(string $nombre)
    {
        $this->usu_Nombre=$nombre;
    }

    public function getUsu_Nom():?string
    {
        return $this->usu_Nombre;
    }

    public function setUsu_Ape(string $apellido)
    {
        $this->usu_Apellido=$apellido;
    }

    public function getUsu_Ape():?string
    {
        return $this->usu_Apellido;
    }

    public function set_UsuCorr(string $correo)
    {
        $this->usu_Correo=$correo;
    }

    public function get_UsuCorr():?string
    {
        return $this->usu_Correo;
    }

    public function set_UsuPass(string $pass)
    {
        $this->usu_Password=$pass;
    }

    public function get_UsuPass():?string
    {
        return $this->usu_Password;
    }

    public function set_UsuSexo(string $sexo)
    {
        $this->usu_Sexo=$sexo;
    }

    public function get_UsuSexo():?string
    {
        return $this->usu_Sexo;
    }

    public function set_UsuFNA(string $fna)
    {
        $this->usu_FNA=$fna;
    }

    public function get_UsuFNA():?string
    {
        return $this->usu_FNA;
    }

    

    public function insertarUsuario(usuario $u)
    {
        try{
            
            $sentencia = "call insertUsuario(?,?,?,?,?,?);";

            $this->pdo->prepare($sentencia)
                ->execute(
                    array(
                        $u->getUsu_Nom(),
                        $u->getUsu_Ape(),
                        $u->get_UsuCorr(),
                        $u->get_UsuPass(),
                        $u->get_UsuSexo(),
                        $u->get_UsuFNA()
                    )
                );
        }
        catch (Exception $e)
        {
            die($e->getMessage());

        }
    }


  public function Validar($user,$pwd){
        try{
            $pwd=md5(sha1($pwd));

            $consulta=$this->pdo->prepare("call validarsesion(?,?)");

            $consulta->execute(array($user,$pwd));
            $u=$consulta->fetch(PDO::FETCH_OBJ);

            if(!empty($u)){
                $_SESSION['user']=$u->usu_user;
                $_SESSION['pass']=$u->usu_pas;
                return true;

            }else{
                session_destroy();
                return false;
            }

        }
         catch(Exception $e){
            die($e->getMessage());

        }

}

    public function Actualizar(usuario $u){
        try{
            $consulta="UPDATE usuarios SET
                        usu_user = ?,
                        usu_pwd = ?,
                        usu_nom = ?,
                        usu_ema = ?,
                        usu_fna = ?,
                        usu_rol = ?

                        WHERE usu_id = ?;";

            $this->pdo->prepare($consulta)
                ->execute(
                    array(
                        $p->getusu_id(),
                        $p->getusu_user(),
                        $p->getusu_pwd(),
                        $p->getusu_nom(),
                        $p->getusu_ema(),
                        $p->getusu_fna(),
                        $p->getusu_rol()
                    )
                );
        }catch(Exception $e){
            die($e->getMessage());
        }
    }


}

