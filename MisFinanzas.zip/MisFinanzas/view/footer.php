<head> <meta charset="utf-8">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/templatemo_style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/templatemo_misc.css">

</head>