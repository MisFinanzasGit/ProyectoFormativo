

<link rel="stylesheet" type="text/css" href="assets/css/modal.css">

    <div id="openModal" class="modalDialog">
      <div>
       <a href="?c=usuario&a=home" class="btn btn-success pull-right" data-dismiss="modal">×</a>
        <form method="POST" action="?c=usuario&a=iniciar" name="loginForm">
           <h4>Inicio de sesión</h4>
            <p><input type="text" class="span3" name="user" id="email" placeholder="Digite Email" value=""></p>
            <p><input type="password" class="span3" id="loginPassword" name="pass" placeholder="Enter Password"></p>
            <p><button type="submit" class="btn btn-success">Sign in</button> <a href="<?= base_url();?>/forgotpassword">Forgot Password</a></p>
        </form>
        </div>
    </div>
