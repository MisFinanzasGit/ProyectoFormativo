<!DOCTYPE html>
<html>
<head>

     <link href="assets/css/modal.css" rel="stylesheet">
    <title>Mis Finanzas</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


</head>
<body>
<header>
    <!-- start menu -->
    <div id="templatemo_home">
        <div class="templatemo_top">
            <div class="container templatemo_container">
                <div class="row">
                    <div class="col-sm-3 col-md-3">
                        <div class="logo">
                            <a href="#"><img src="assets/images/templatemo_logo.png" alt="smoothy html5 template"></a>
                        </div>
                    </div>
                    <div class="col-sm-9 col-md-9 templatemo_col9">
                        <div id="top-menu">
                            <nav class="mainMenu">
                                <ul class="nav">
                                    <li><a class="menu" href="#templatemo_home">Home</a></li>
                                    <li><a class="menu" data-toggle="modal" href="#openModal">Login</a></li>
                                    <li><a class="menu" href="?c=usuario&a=Crear">Registrarse</a></li>
                                    <li><a class="menu" href="#templatemo_contact">Contacto</a></li>


                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 

    <div class="clear"></div>
    <!-- end menu -->
    <a href="#"><img src="assets/images/slider/verde.jpg" alt="slide 3" /></a>
</header>
<!-- Menú -->
<div class="templatemo_lightgrey_about" id="templatemo_about">
    <div class="container">
        <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
            <div class="item project-post">
                <div class="templatemo_about_box">
                    <div class="square_coner">
                        <span class="texts-a"><i class="fa fa-bell-o"></i></span>
                    </div>
                    Como funciona</div>
                <div class="col-xs-12 col-sm-6 col-md-3 hover-box" >
                    <div class="inner-hover-box">
                        <p>Nunc sed ullamcorper massa, vitae tristique lectus. Curabitur ultricies, nunc ac tincidunt sollicitudin, neque leo commodo nisl.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12">
            <div class="item project-post">
                <div class="templatemo_about_box">
                    <div class="square_coner">
                        <span class="texts-a"><i class="fa fa-tablet"></i></span>
                    </div>
                    Como funciona</div>
                <div class="col-xs-6 col-sm-6 col-md-3 hover-box" >
                    <div class="inner-hover-box">
                        <p>Morbi ac vestibulum nisl. Praesent lacinia id mi eget dictum. Fusce egestas turpis nec erat lobortis, ut tempus purus suscipit.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 templatemo_margintop10">
            <div class="item project-post">
                <div class="templatemo_about_box">
                    <div class="square_coner">
                        <span class="texts-a"><i class="fa fa-lock"></i></span>
                    </div>
                    Como funciona</div>
                <div class="col-xs-6 col-sm-6 col-md-3 hover-box" >
                    <div class="inner-hover-box">
                        <p>Etiam venenatis egestas magna sit amet varius. Vivamus neque eros, sollicitudin a ligula quis, interdum venenatis justo.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-3 templatemo_col12 templatemo_margintop10">
            <div class="item project-post">
                <div class="templatemo_about_box">
                    <div class="square_coner">
                        <span class="texts-a"><i class="fa fa-rocket"></i></span>
                    </div>
                   Como funciona</div>
                <div class="col-xs-6 col-sm-6 col-md-3 hover-box" >
                    <div class="inner-hover-box">
                        <p>Vestibulum convallis leo vel tortor ultricies aliquam. Nullam faucibus urna vel volutpat ornare. Donec molestie accumsan ante.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Footer End-->
<div class="clear"></div>
<div class="">
    <h2></h2>
    <p></p>
    <div class="clear height10"></div>
    <div class="fa fa-bell-o"></div>
    <div class="fa fa-tablet"></div>
    <div class="fa fa-lock"></div>
    <div class="clear height20"></div>
    <a class="btn btn-large btn-primary" href="#"></a>
</div>


<div class="clear"></div>
<!-- Bottom Start -->
<div class="templatemo_bottom">
    <div class="container">
        <div class="row">
            <div class="left">Copyright © 2084 <a href="#"></a>
                - Design: <a rel="nofollow" href=""></a></div>

        </div>
    </div>
</div>
<!-- Bottom End -->



</body>



</html>

<div style="text-align: center; font-size: 0.75em;"> <a target='_blank' title='s' href=''></a> - <a target='_blank' title='' href=''></a></div>

<div id="openModal" class="modalDialog" >
      <div class="modal-content">
       <a href="?c=usuario&a=home" class="btn btn-success pull-right" data-dismiss="modal">×</a>
        <form method="POST" action="?c=usuario&a=iniciar" name="loginForm">
           <h4>Inicio de sesión</h4>
            <p><input type="text" class="span3" name="user" id="email" placeholder="Digite Email" value=""></p>
            <p><input type="password" class="span3" id="loginPassword" name="pass" placeholder="Enter Password"></p>
            <p><button type="submit" class="btn btn-success">Sign in</button> <a href="<?= base_url();?>/forgotpassword">Forgot Password</a></p>
        </form>
        </div>
    </div>