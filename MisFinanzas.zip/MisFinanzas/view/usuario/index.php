<!DOCTYPE html>
<html>
<head>
    <title>Ajustes</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body style="background-color: >



	<div class="panel panel-default" style="width: 20%; position: relative; center: 1000px; ">
<div class="panel-body" style="background-color: ;">
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Opciones"><br>
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Sistema"><br>
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Moneda"><br>
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Cuenta"><br>
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Actualizar informacion"><br>
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Seguridad"><br>
    <input type="button" name="" class="btn-info" style="width: 200px;" value="Cambiar Contraseña"><br>

</div>
</div>

<div class="panel panel-default" style="width: 60%; position: relative; left: 25%; top: -180px;">
    <div margin="0" class="panel-body" style="background-color: "" >

<form action="?c=usuario&a=guardar" method="POST">
        <center>
            <h3><b>Actualizar informacion personal</b></h3><hr>


            <div class="input-group" style="position: relative; left: 30%;">
                <span class="input-group-addon" style="background-color: #6ACF62; color: white;">Nombre</span>
                <input type="text" class="form-control" name="Nombre" style="width: 200px;">
            </div><br>


            <div class="input-group" style="position: relative; left: 30%;">
                <span class="input-group-addon" style="background-color: #6ACF62; color: white;">Apellido</span>
                <input type="text" class="form-control" name="Apellido" style="width: 200px;">
            </div><br>

            <div class="input-group" style="position: relative; width: 40%;">
                <span class="input-group-addon" style="background-color: #6ACF62; color: white;">Correo</span>
                <input type="text" class="form-control" name="Correo">
            </div><br>

            <div class="input-group" style="position: relative; left: 30%;">
                <span class="input-group-addon" style="background-color: #6ACF62; color: white;">Fecha Nacimiento</span>
                <input type="date" class="form-control" name="FNA" style="width: 200px;">
            </div><br>




            <input type="submit" class="btn btn-success" value="Guardar Cambios" name="">
        </center>
</form>

    </div>
</div>



</body>
</html>