
<h2>Presupuesto</h2>
<br>
<h3>Tabla de Gastos</h3>

<table class="table table-striped table-hover" id="Gastos">
    <thead>
    <tr>

        <td>Nombre Gasto</td>
        <td>Presupuesto</td>
        <td>Categoria</td>
        <td>Descripcion</td>

        <td></td>
        <td></td>
    </tr>
    </thead>
    <tbody>
    <?php foreach($gasto->Listar() as $r):?>
    <tr>
        <td><?=$r->gasto_nombre?></td>
        <td> <?=$r->gasto_presupuesto?></td>
        <td> <?=$r->gasto_categoria?></td>
        <td><?=$r->gasto_descripcion?></td>
        <td>
        </td>

        <?php endforeach;?>
    </tbody>
</table>

<button type="button" class="btn-info" data-toggle="modal" data-target="#cpresupuesto">Crear Presupuesto</button>



<div class="modal fade" id="cpresupuesto" role="dialog">
    <div class="modal-dialog" style="width: 350px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h6 class="modal-title"><b>Crear Presupuesto</b></h6>

            </div>
            <div class="modal-body">

                <form action="?c=presupuesto&a=Guardar" method="POST">




                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"   style="background-color: #6ACF62;color: white;"><b>Nombre</b></span>
                        <input type="text" class="form-control"  name="Nombre" style="width: 198px;">
                    </div><br>

                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"  style="background-color: #6ACF62;color: white;"><b>Cuenta</b></span>
                        <select style="width: 188px;" class="form-control" name="Cuenta" id="sel1">

                            <option value="">Seleccione tipo de cuenta</option>
                            <?php foreach($c->ListarTodo() as $r):?>



                                <option value="<?=$r->idCuenta?>"
                                    <?=$pto->getPresu_Cuenta()==$r->idCuenta ? "selected" : "" ?>>
                                    <?=$r->cuenta_nom?></option>

                            <?php endforeach;?>

                        </select>


                    </div><br>

                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"  style="background-color: #6ACF62;color: white;"><b>Monto</b></span>
                        <input type="text" class="form-control" name="Monto" style="width: 170px;">
                    </div><br>


                    <input type="submit" class="btn-success" value="Guardar Cambios">

                </form>


            </div>
        </div>
    </div>
</div>


<button type="button" class="btn-info" data-toggle="modal" data-target="#cgasto">Crear Gasto</button>



<div class="modal fade" id="cgasto" role="dialog">
    <div class="modal-dialog" style="width: 350px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h6 class="modal-title"><b>Crear Gasto</b></h6>

            </div>
            <div class="modal-body">

                <form action="?c=gasto&a=Guardar" method="POST">




                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"   style="background-color: #6ACF62;color: white;"><b>Nombre</b></span>
                        <input type="text" class="form-control"  name="Nombre" style="width: 198px;">
                    </div><br>


                        <select style="width: 188px;" class="form-control" name="PTO" id="sel1">

                            <option value="">Seleccione el presupuesto</option>
                            <?php foreach($pto->Listar() as $r):?>



                                <option value="<?=$r->idPresupuesto?>"
                                    <?=$gasto->getGasto_presupuesto()==$r->idPresupuesto ? "selected" : "" ?>>
                                    <?=$r->presu_Nombre?></option>

                            <?php endforeach;?>

                        </select>

                    <br>
                    <br>

                    <select style="width: 188px;" class="form-control" name="CTA" id="sel1">

                        <option value="">Seleccione la categoria del gasto</option>
                        <?php foreach($cat->Listar() as $r):?>



                            <option value="<?=$r->idCategoria?>"
                                <?=$gasto->getGasto_categoria()==$r->idCategoria ? "selected" : "" ?>>
                                <?=$r->categoria_tipo?></option>

                        <?php endforeach;?>

                    </select>


                    </div><br>


            <div class="form-group">
                <p style="position: relative; left: 10px;"><label for="comment">Descripcion:</label>
                    <textarea class="form-control" name="Descripcion" rows="4" id="comment" style="width: 300px;"></textarea></p>
            </div>

          <br>


            <center><input type="submit" class="btn-success" value="Guardar Cambios"></center>

                </form>


            </div>
        </div>
    </div>
</div>


<button type="button" class="btn-info" data-toggle="modal" data-target="#ccategoria">Crear Categoria</button>



<div class="modal fade" id="ccategoria" role="dialog">
    <div class="modal-dialog" style="width: 350px;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h6 class="modal-title"><b>Crear Categoria</b></h6>

            </div>
            <div class="modal-body">

                <form action="?c=categoria&a=Guardar" method="POST">




                    <div class="input-group" style="position: relative; left: 30px;">
                        <span class="input-group-addon"   style="background-color: #6ACF62;color: white;"><b>Nombre Categoria</b></span>
                        <input type="text" class="form-control"  name="Nombre" style="width: 120px;">
                    </div><br>

                    <!--Categoria icon
                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"  style="background-color: #6ACF62;color: white;"><b>Representación iconográfica</b></span>
                        <select style="width: 188px;" class="form-control" name="icon" id="sel1">


                        -->

                    <center><input type="submit" class="btn-success" value="Guardar Cambios"></center>

                </form>


            </div>
        </div>
    </div>
</div>