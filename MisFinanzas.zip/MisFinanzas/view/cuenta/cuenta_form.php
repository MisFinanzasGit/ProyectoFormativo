 <form action="?c=cuenta&a=Guardar" method="POST" class="form-horizontal" id="contactform">
            <p class="contact"><label for="name">Nombre Cuenta</label></p>
            <input id="name" name="Nombre" placeholder="" required="" tabindex="1" type="text">

            <p class="contact"><label for="apellido">Apellido</label></p>
            <input id="apellido" name="Apellido" placeholder="" required="" tabindex="1" type="text">

            <p class="contact"><label for="email">Email</label></p>
            <input id="email" name="Correo" placeholder="ejemplo@dominio.com" required="" type="email">


            <p class="contact"><label for="password">Contraseña</label></p>
            <input type="password" id="password" name="Pass" required="">
            <p class="contact"><label for="repassword">Confirmación de contraseña</label></p>
            <input type="password" id="repassword" name="Pass" required="">

            <p class="contact"><label for="repassword">Fecha de nacimiento: </label></p>
            <input type="date" id="FNA" name="FNA" required="">

            <p class="contact"><label for="sexo">Sexo:</label></p>
            <select class="select-style gender" name="Sexo" id="sexo">
                <option value="select">Seleccione</option>
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
            </select><br><br>
