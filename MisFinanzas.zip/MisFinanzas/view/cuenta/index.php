<h2>Cuentas</h2>
<table class="table table-striped table-hover" id="Productos">
    <thead>
    <tr>

        <td>Nombre cuenta</td>
        <td>Tipo cuenta</td>
        <td>Monto cuenta</td>
        <td>Saldo cuenta</td>

        <td></td>
        <td></td>
    </tr>
    </thead>
    <tbody>
    <?php foreach($this->model->Listar() as $r):?>
        <tr>
        <td><?=$r->cuenta_nom?></td>
        <td><?=$r->cuenta_tipo?></td>
        <td>$ <?=number_format($r->cuenta_monto,0,",",".")?></td>
        <td>$ <?=number_format($r->cuenta_saldo,0,",",".")?></td>
        <td>
        </td>

    <?php endforeach;?>
    </tbody>
</table>


<button type="button" class="btn-info" data-toggle="modal" data-target="#ccuenta">Añadir cuenta</button>



    <div class="modal fade" id="ccuenta" role="dialog">
        <div class="modal-dialog" style="width: 350px;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h6 class="modal-title"><b>Añadir Cuentas</b></h6>
                </div>
                <div class="modal-body">

                    <form action="?c=cuenta&a=Guardar" method="POST">

                        


                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"   style="background-color: #6ACF62;color: white;"><b>Nombre</b></span>
                        <input type="text" class="form-control"  name="Nombre" style="width: 198px;">
                    </div><br>

                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"  style="background-color: #6ACF62;color: white;"><b>Tipo</b></span>
                        <select style="width: 188px;" class="form-control" name="Tipo" id="sel1">

                            <option value="">Seleccione tipo de cuenta</option>
                            <?php foreach($tc->Listar() as $r):?>



                                <option value="<?=$r->idcuenta_tipo?>"
                                    <?=$c->getCuenta_tipo()==$r->idcuenta_tipo ? "selected" : "" ?>>
                                    <?=$r->tipo_cuenta?></option>

                            <?php endforeach;?>

                        </select>


                    </div><br>

                    <div class="input-group" style="position: relative; left: 20px;">
                        <span class="input-group-addon"  style="background-color: #6ACF62;color: white;"><b>Monto</b></span>
                        <input type="text" class="form-control" name="Monto" style="width: 170px;">
                    </div><br>


                    <input type="submit" class="btn-success" value="Guardar Cambios">





</form>





