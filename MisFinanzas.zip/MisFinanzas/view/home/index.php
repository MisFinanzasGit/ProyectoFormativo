﻿<!DOCTYPE html>
<html>
<head>
    <title></title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--LINKS FOOTER-->

</head>
<body style="background-color: ">


<!-- TABS PRINCIPALES -->

<br><br>
<div class="container">

    <ul class="nav nav-tabs">
        <li class="active"><a data-toggle="tab" href="#resumen">Resumen</a></li>
        <li><a data-toggle="tab" href="#movimientos">Movimientos</a></li>
        <li><a data-toggle="tab" href="#presupuesto">Presupuesto</a></li>
        <li><a data-toggle="tab" href="#metas">Metas</a></li>
        <li><a data-toggle="tab" href="#reportes">Reportes</a></li>
    </ul>
    <br>

    <!-- RESUMEN -->

    <div class="tab-content">

        <div id="resumen" class="tab-pane fade in active">

            <!-- PANEL 1 RESUMEN -->

            <div class="panel panel-default" style=" position: relative; width: 60%;">
                <div class="panel-body" style="background-color: #F5F5F2;">

                    <div class="input-group col-xs-8">
                        <span class="input-group-addon"><b>Gastando por Categoria</b></span>
                        <input type="text" class="form-control" name="" placeholder="$">
                    </div><br>


                    <div class="progress">
                        <div class="progress-bar" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:40%">
                            40% Gastado
                        </div>
                    </div> <hr>

                    <p><h5 style="position: relative; left: 10px;"><b>Movimientos:</b></h5></p>

                    <div class="table-responsive">
                        <table class="table table-bordered" name="">
                            <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Categoria</th>
                                <th>Gasto</th>
                                <th>Nombre Movimiento</th>
                                <th>Monto</th>
                            </tr>
                            </thead>

                            <tbody>
                            <tr>
                                <td>11/12/2017</td>
                                <td>Alimentación</td>
                                <td>Comida</td>
                                <td>Frutas</td>
                                <td>$20.000</td>
                            </tr>
                            <tr>
                                <td>11/11/2017</td>
                                <td>Ropa</td>
                                <td>Koaj</td>
                                <td>Jeans</td>
                                <td>$100.000</td>
                            </tr>
                            <tr>
                                <td>19/10/2017</td>
                                <td>Vivienda</td>
                                <td>Alquiler</td>
                                <td>Arriendo</td>
                                <td>$420.000</td>
                            </tr>

                            </tbody>
                        </table>
                    </div>



                </div>
            </div>

            <!-- PANEL 2 RESUMEN -->

            <div class="panel panel-default" style="width: 30%; position: relative; left: 65%; top: -355px;">
                <div class="panel-body" style="background-color: #F5F5F2;">

                    <p><h4>Presupuesto:</h4></p>
                    <div class="progress">
                        <div class="progress-bar progress-bar-info" name="" role="progressbar" aria-valuenow="80"
                             aria-valuemin="0" aria-valuemax="100" style="width:80%">20.000$ Restantes
                        </div>
                    </div><hr>
                    <p><h4>Balances:</h4></p>

                    <div class="form-group">
                        <textarea class="form-control" name="" rows="4" id="comment""></textarea></p>
                    </div>

                    <hr>
                    <p><h5><b>Principales Categorias de Gasto:</b></h5></p><br>
                    <div class="container">
                        <span class="glyphicon glyphicon-home" style="width: 130px;"></span><span class="glyphicon glyphicon-shopping-cart" style="width: 130px;"></span> <span class="glyphicon glyphicon-briefcase"></span>
                    </div> <hr>



                </div>
            </div>


        </div>


        <!-- MOVIMIENTOS  -->

        <div id="movimientos" class="tab-pane fade">

            <!--PANEL 1 MOVIMIENTO -->

            <div class="panel panel-default" style="width: 65%;">
                <div class="panel-body" style="background-color: #F5F5F2;">
                    <p>

                    <h4><b>Todos los movimientos:</b></h4>
                    <h5>Usted tiene 1 cuenta. <a href="">Añadir Otra?</a></h5>

                    <center>
                        <div class="input-group col-xs-4" style="position: relative;">
                            <input type="text" name="" class="form-control" placeholder="Search">
                            <div class="input-group-btn">
                                <button class="btn btn-default" name="" type="submit">
                                    <i class="glyphicon glyphicon-search"></i>
                                </button>
                            </div>
                        </div></center>

                    </p><hr>

                    <p><center>
                        <div class="input-group col-xs-5">
                            <span class="input-group-addon" name="">Total Disponible</span>
                            <input type="text" class="form-control" name="" placeholder="$">
                        </div>
                    </center>
                    </p>


                    <center><button type="button" class="btn-info" data-toggle="modal" name="" data-target="#myModal">Añadir movimiento</button><hr></center>

                    <div class="table-responsive">
                        <table class="table table-bordered" name="" style="width: 90%; position: relative; left: 10px;">
                            <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Categoria</th>
                                <th>Gasto</th>
                                <th>Movimiento</th>
                                <th>Monto</th>
                            </tr>
                            </thead>

                            <tbody>
                            <tr>
                                <td>11/12/2017</td>
                                <td>Alimentación</td>
                                <td>Comida</td>
                                <td>Frutas</td>
                                <td>$20.000</td>
                            </tr>
                            <tr>
                                <td>11/11/2017</td>
                                <td>Ropa</td>
                                <td>Koaj</td>
                                <td>Jeans</td>
                                <td>$100.000</td>
                            </tr>
                            <tr>
                                <td>19/10/2017</td>
                                <td>Vivienda</td>
                                <td>Alquiler</td>
                                <td>Arriendo</td>
                                <td>$420.000</td>
                            </tr>

                            </tbody>
                        </table>
                    </div>


                    <!-- MODAL MOVIMIENTOS -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog" style="width: 500px;">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h6 class="modal-title"><b>Añadir Transacción</b></h6>
                                </div>
                                <div class="modal-body">

                                    <FORM method="" action="" name="ModalMov">

                                        <!-- TAB-TAB MOVIMIENTOS -->

                                        <div class="container" style="width: 99%;">


                                            <ul class="nav nav-tabs">
                                                <li class="active"><a data-toggle="tab" href="#gastos"><b>Gastos</b></a></li>
                                                <li><a data-toggle="tab" href="#transferencia"><b>Transferencia</b></a></li>
                                                <li><a data-toggle="tab" href="#ingresos"><b>Ingresos</b></a></li>
                                            </ul>
                                            <br>



                                            <div class="tab-content" style="background-color: #E5E5E5; border-width: :1px;border-color: #CFCECE; border-style: solid;">

                                                <div id="gastos" class="tab-pane fade in active">
                                                    <br>
                                                    <div class="input-group" style="position: relative; left: 90px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white; color: white;">Fecha</span>
                                                        <input type="date" class="form-control" style="width: 200px;" name="fecha">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 90px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Gasto</span>
                                                        <input type="text" class="form-control" name="gasto" style="width: 200px;" placeholder="$">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 90px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Valor</span>
                                                        <input type="text" class="form-control" name="valor" style="width: 205px;" placeholder="$">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 90px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Categoria:</span>
                                                        <select style="width: 172px;" name="" class="form-control" id="sel1">
                                                            <option>Seleccione</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 90px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Cuenta:</span>
                                                        <select style="width: 187px;" name="" class="form-control" id="sel2">
                                                            <option>Seleccione</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="form-group">
                                                        <p style="position: relative; left: 30px;"><label for="comment">Notas:</label>
                                                            <textarea class="form-control" rows="4" id="comment" name="" style="width: 370px;"></textarea></p><br>
                                                    </div>

                                                </div>


                                                <div id="transferencia" class="tab-pane fade"><br>

                                                    <div class="input-group" style="position: relative; left: 75px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Fecha</span>
                                                        <input type="date" class="form-control" style="width: 200px;" name="fecha">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 75px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Valor</span>
                                                        <input type="text" class="form-control" name="valor" style="width: 205px;" placeholder="$">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 55px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Cuenta de origen:</span>
                                                        <select style="width: 176px;" name="" class="form-control" id="sel1">
                                                            <option>Seleccione</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 55px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Cuenta de destino:</span>
                                                        <select style="width: 170px;" name="" class="form-control" id="sel2">
                                                            <option>Seleccione</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="form-group">
                                                        <p style="position: relative; left: 40px;"><label for="comment">Notas:</label>
                                                            <textarea class="form-control" name="" rows="4" id="comment" style="width: 350px;"></textarea></p><br>
                                                    </div>

                                                </div>


                                                <div id="ingresos" class="tab-pane fade"><br>
                                                    <div class="input-group" style="position: relative; left: 85px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Fecha</span>
                                                        <input type="date" class="form-control" style="width: 200px;" name="fecha">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 85px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Valor</span>
                                                        <input type="text" class="form-control" name="valor" style="width: 205px;" placeholder="$">
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 85px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Categoria:</span>
                                                        <select style="width: 172px;" class="form-control" id="sel1">
                                                            <option>Seleccione</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="input-group" style="position: relative; left: 85px;">
                                                        <span class="input-group-addon" style="background-color: #6ACF62;color: white;">Cuenta:</span>
                                                        <select style="width: 187px;" class="form-control" id="sel2">
                                                            <option>Seleccione</option>
                                                        </select>
                                                    </div><br>

                                                    <div class="form-group">
                                                        <p style="position: relative; left: 35px;"><label for="comment">Notas:</label>
                                                            <textarea class="form-control" name="" rows="4" id="comment" style="width: 360px;"></textarea></p><br>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>

                                <div class="modal-footer">
                                    <center>
                                        <input type="submit" class="btn btn-success" value="Guardar">
                                        <input type="submit" class="btn btn-primary" value="Guardar & Nuevo">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                    </center>
                                </div>

                                </FORM>


                            </div>

                        </div>
                    </div>

                </div>

            </div>

            <!--PANEL 2 MOVIMIENTO -->

            <div class="panel panel-default" style="width: 30%; position: relative; top: -460px; left: 70%;">
                <div class="panel-body" style="background-color: #F5F5F2;">

                    <p><h4>Cuentas de Gasto:</h4></p>
                    <div class="input-group">
                        <span class="input-group-addon">Saldo Disponible</span>
                        <input type="text" class="form-control" name=""  placeholder="$">
                    </div><br>

                    <p><h4>Cuentas de Ahorro:</h4></p>

                    <p>
                        Fondo de emergencia
                    <div class="input-group">
                        <span class="input-group-addon">Saldo Disponible</span>
                        <input type="text" class="form-control  col-xs-4" name="" placeholder="$">
                    </div>

                    </p><br>

                    <center><input type="button" name="" class="btn btn-warning" value="Gestionar Cuentas"></center><hr>
                    <p><h4>Resumen Actividad:</h4></p>

                    <center>
                        <div class="input-group col-xs-7">
                            <span class="input-group-addon">TOTAL</span>
                            <input type="text" class="form-control" name="" placeholder="$">
                        </div>
                        <div class="input-group col-xs-7">
                            <span class="input-group-addon">Gastado</span>
                            <input type="text" class="form-control" name="" placeholder="$">
                        </div>
                    </center>


                </div>
            </div>

        </div>

        <!--TAB PRESUPUESTO-->

        <div id="presupuesto" class="tab-pane fade">
            <div class="panel panel-default" style="width: 42%;"  style="background-color: #F5F5F2;">
                <div class="panel-body">

                    <p><h4><b>Transacciones recientes:</b></h4></p>
                    <div class="table-responsive">
                        <table class="table table-bordered" name="" style="width: 75%; position: relative; left: 10px;">
                            <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Categoria</th>
                                <th>Gasto</th>
                                <th>Movimiento</th>
                                <th>Monto</th>
                            </tr>
                            </thead>

                            <tbody>
                            <tr>
                                <td>11/12/2017</td>
                                <td>Alimentación</td>
                                <td>Comida</td>
                                <td>Frutas</td>
                                <td>$20.000</td>
                            </tr>
                            <tr>
                                <td>11/11/2017</td>
                                <td>Ropa</td>
                                <td>Koaj</td>
                                <td>Jeans</td>
                                <td>$100.000</td>
                            </tr>
                            </tbody>
                        </table>
                    </div><hr>
                    <p><h4 style="position: relative; left: 10px;"><b>Cuentas:</b></h4></p>
                    <p><h5 style="position: relative; left: 10px;"><b>Cuentas de Gastos</b></h5></p>
                    <li><span class="glyphicon glyphicon-piggy-bank"></span> Efectivo .............................................. $0</li>

                    <li><span class="glyphicon glyphicon-briefcase"></span> Nomina ............................................ $1.000.000</li>

                    <p><h5 style="position: relative; left: 10px;"><b>Cuentas de Ahorro</b></h5></p>

                    <li><span class="glyphicon glyphicon-fire"></span> Fondo de Emergencia .................................... $0</li><br>
                    <center>
                        <input type="button" onclick="window.location.href='?c=cuenta&a=crear'"  name="" class="btn btn-warning" value="Añadir/Editar" ></center>

                </div>
            </div>

            <div class="panel panel-default" style="width: 55%; position: relative; top: -470px; left: 45%;">
                <div class="panel-body">

                    <center><p><h3><b>Top Categorias de Gasto</b></h3></p><hr></center><br>
                    <CENTER><img src="assets/images/img.PNG"></CENTER><BR>

                    <input type="button" onclick="window.location.href='?c=presupuesto&a=crear'"  name="" class="btn btn-warning" value="Ajustar Presupuesto" ></center>


                </div>
            </div>

        </div>

        <!--TAB METAS-->

        <div id="metas" class="tab-pane fade">
            <div class="panel panel-default"  style="background-color: #F5F5F2;">

                <div class="panel-body">
                    <div class="container">
                        <h4><b>Metas Financieras:</b></h4><br>
                        <p>Ahorrando $<?php foreach($mf->costoMetas() as $r):?>
                                <b><?=$r->costometa?></b>
                            <?php endforeach;?>  para <?php foreach($mf->nMetas() as $r):?>
                        <b><?=$r->nmetas?></b>
                        <?php endforeach;?> Metas</p>
                        <button type="button" class="btn-info" data-toggle="modal" data-target="#meta">Añadir Meta Financiera</button>
                    </div><hr>

                    <table class="table table-striped table-hover" id="Productos">
                        <thead>
                        <tr>


                            <td>Meta nombre</td>
                            <td>Meta costo</td>
                            <td>Meta tipo</td>


                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($mf->Listar() as $r):?>
                          <tr>
                              <td><?=$r->meta_nom?></td>
                              <td><?=$r->meta_costo?></td>
                              <td><?=$r->meta_tipo?></td>


                          </tr>



                            </td>

                            <?php endforeach;?>
                        </tbody>
                    </table>

                    <div class="container">


                        <p>
                            <span class="glyphicon glyphicon-plane"></span><b>*Viaje</b>
                        <p>
                            <input type="button" name="" class="btn-default" value="Añadir">
                            <input type="button" name="" class="btn-default" value="Ajustar">
                            <input type="text" name="">
                        <div class="progress" style="width: 30%;">
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:80%">$855.000 de $1.000.000</div>
                        </div>
                        </p>
                        </p>

                    </div>


                </div>

            </div>

            <div class="modal fade" id="meta" role="dialog">
                <div class="modal-dialog" style="width: 350px;">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h6 class="modal-title"><b>Añadir Meta Financiera</b></h6>
                        </div>
                        <div class="modal-body">

                            <form action="?c=meta&a=guardar" method="POST"  name="ModalMov">
                                <div class="input-group" style="position: relative; left: 20px;">
                                <span class="input-group-addon" style="background-color: #6ACF62;color: white;"><b>Nombre</b></span>
                                <input type="text" class="form-control" name="Nombre" style="width: 198px;">
                        </div><br>

                                <div class="input-group" style="position: relative; left: 20px;">
                                    <span class="input-group-addon" style="background-color: #6ACF62;color: white;"><b>Costo</b></span>
                                    <input type="text" class="form-control" name="Costo" style="width: 210px;">
                                </div><br>

                        <div class="input-group" style="position: relative; left: 20px;">
                            <span class="input-group-addon" style="background-color: #6ACF62;color: white;"><b>Tipo</b></span>

                                <select style="width: 188px;" class="form-control" name="Tipo" id="sel1">

                                    <option value="">Seleccione tipo de meta</option>
                                    <?php foreach($tmf->Listar() as $r):?>



                                        <option value="<?=$r->idtipo_meta?>"
                                            <?=$mf->getMeta_tipo()==$r->idtipo_meta ? "selected" : "" ?>>
                                            <?=$r->tipo_meta?></option>

                                    <?php endforeach;?>

                                </select>
                            </select>
                        </div><br>


                                <center><input type="submit" class="btn-success" value="Guardar Cambios"></center>

                            </form>

                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!--TAB REPORTES-->

        <div id="reportes" class="tab-pane fade">

            <!--PANEL 1 REPORTES -->
            <div class="panel panel-default"  style="width: 280px; position: relative; left: 10px; background-color: #F5F5F2;">
                <div class="panel-body">

                    <FORM method="" action="" name="GenerarReporte">

                        <p><h4><b>1. Generar Reporte</b></h4></p>

                        <p style="position: relative; left: 10px;"><b>Establecer la fecha:</b></p>

                        <div class="input-group" style="position: relative; left: 20px;">
                            <span class="input-group-addon" style="background-color: #6ACF62;color: white;"><b>De</b></span>
                            <input type="date" class="form-control" name="" style="width: 162px;">
                        </div>

                        <div class="input-group" style="position: relative; left: 20px;">
                            <span class="input-group-addon" style="background-color: #6ACF62;color: white;"><b>A</b></span>
                            <input type="date" class="form-control" name="" style="width: 170px;">
                        </div> <br>

                        <p style="position: relative; left: 10px;"><b>Tipo de reporte:</b></p>
                        <select name="reporte" class="form-control" id="sel1" style="position: relative; width: 208px; left: 20px;">
                            <option value="Seleccione">Seleccione</option>
                        </select>
                        <hr>

                        <p style="position: relative; left: 10px;"><b>Visualizar por:</b></p>
                        <p style="position: relative; left: 20px;"><input type="checkbox" name=""> Gastos a traves del Tiempo<br>
                            <input type="checkbox" name=""> Categoria
                        <hr></p>
                        <center><input type="submit" class="btn-primary" name="" value="Generar Reporte"></center>
                    </FORM>
                </div>
            </div>


            <!--PANEL 2 REPORTES -->
            <div class="panel panel-default"  style="position: relative; top:-450px; left: 320px; width: 70%; background-color: #F5F5F2;">
                <div class="panel-body">

                    <p style="position: relative; left: 10px;"><h4><b>2. Escoja la grafica:</b></h4><br>

                    <script type="text/javascript" language="javascript">
                        function circulo() {
                            img = document.getElementById('circulo');
                            img.innerHTML = '<img style="position: relative; width:20%;" src="img/circular.ico"/>';
                        }

                        function barras() {
                            img = document.getElementById('circulo');
                            img.innerHTML = '<img style="position: relative; width:20%;" src="img/barras.png"/>';
                        }
                    </script>

                    <input type="button" name="" class="btn-warning" value="Circular" onclick="circulo()"></a>
                    <input type="button" name="" class="btn-info" Value="Barras" onclick="barras()"><br><br>

                    <hr>
                    <p style="position: relative; left: 10px;"><h4><b>3. Obtenga el reporte:</b></h4><br>
                    <center>
                        <p id="circulo"></p>
                        Total Gastos Mensuales <input type="text" name="" placeholder="$">
                    </center>
                    <br>
                </div>
            </div>
        </div>
    </div>
</div>

</div>

<!--FOOTER-->

</body>
</html>