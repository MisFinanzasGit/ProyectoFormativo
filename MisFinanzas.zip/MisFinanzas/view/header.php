<header>

    <!--- Header --->

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <nav class="navbar navbar-default" style="background-color: #E5F2E7;">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="?c=home&a=index"><img style="position: relative; top: -60px; width: 18%; left: 25px;" src="assets/images/templatemo_logo.png" alt="smoothy html5 template"></a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                <li><a href="?c=usuario&a=index"><span class="glyphicon glyphicon-cog"></span> Ajustes</a></li>
                <li><a href="?c=usuario&a=cerrar"><span class="glyphicon glyphicon-log-out"></span> Cerrar Sesion</a></li>
            </ul>
        </div>
    </nav>
</header>